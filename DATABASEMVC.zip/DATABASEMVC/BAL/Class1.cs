﻿namespace BAL;

public class Class1
{

}
